<?php
//validamos datos del servidor
$user = "root";
$pass = "";
$host = "localhost";

//conetamos al base datos
$connection = mysqli_connect($host, $user, $pass);

//ESTO SE ALMACENA EN LA TABLA POSTULADO
$Nombre = $_POST['Nombre'];
$ApellidoP = $_POST['App'];
$ApellidoM = $_POST['Apm'];
$EstCivil = $_POST['EstCivil'];
$Sexo = $_POST['Sexo'];
$FechaNac = $_POST['FechaNac'];
$Edad = $_POST['Edad'];
$Estado = $_POST['Estado'];
$Municipio = $_POST['Municipio'];
$Calle = $_POST['Calle'];
$Telefono = $_POST['Telefono'];
$Correo = $_POST['Correo'];

//ESTO SE ALMACENA EN LA TABLA CVU

$NivelAca = $_POST['NivelAca'];
$Area = $_POST['Area'];
$ConocimiemtosAca = $_POST['ConAca'];
$Descripcion = $_POST['PresPro'];
$Sueldo = $_POST['SueldoD'];

//verificamos la conexion a base datos
if(!$connection) 
        {
            echo "No se ha podido conectar con el servidor";
        }
  else
        {
            echo "<b><h3>Hemos conectado al servidor</h3></b>" ;
        }
        //indicamos el nombre de la base datos
        $datab = "desempleo";
        //indicamos selecionar ala base datos
        $db = mysqli_select_db($connection,$datab);

        if (!$db)
        {
        echo "No se ha podido encontrar la Tabla";
        }
        else
        {
        echo "<h3>Tabla seleccionada:</h3>" ;
        }
        //insertamos datos de registro al mysql xamp, indicando nombre de la tabla y sus atributos
        $instruccion_SQL = "INSERT INTO Postulado (Nombre,ApellidoP,ApellidoM,EstCivil,Sexo,FechaNac,Edad,Estado,Municipio,Calle,Telefono,Correo )
                             VALUES ('$Nombre','$ApellidoP','$ApellidoM','$EstCivil','$Sexo','$FechaNac','$Edad','$Estado','$Municipio','$Calle','$Telefono','$Correo' )";
        
        $instruccion2_SQL = "INSERT INTO CVU ( NivelAca,Area,ConocimiemtosAca,Descripcion,Sueldo)
                             VALUES ('$NivelAca','$Area','$ConocimiemtosAca','$Descripcion','$Sueldo' )";                   
                            
        $resultado = mysqli_query($connection,$instruccion_SQL,$instruccion2_SQL);
?>