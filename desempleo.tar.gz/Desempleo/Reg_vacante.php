<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/app.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <title>Postularme</title>
</head>
<body>
     <!--div menu -->
     <ul class="nav justify-content-center navbar navbar-dark bg-primary">
        <li class="navbar-brand">
            <a class="btn btn-light" href="/">Inicio</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Nosotros">Nosotros</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Info">Más información</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="Reg_empresa.html">Registrar empresa</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-warning" href="/Postularme">Postularme</a>
        </li>
    </ul>
<br>
<div class="container">
<br><br>
<h3>Requisitos para postularse</h3>
<br>
  <form  >
    <div class="container">
    <!--div Datos profesionales-->
  <div class="input-group">
      <label class="input-group-text">Nivel de estudios</label>
          <select class="form-control" id="NivelAca">
              <option>los tomara de la base de datos </option>
          </select>

      <label class="input-group-text">Area profesional</label>
        <select class="form-control" id="area">
          <option>los tomara de la base de datos </option>
        </select>
  </div>
  <br>
  <div class="input-group">
      <label class="input-group-text">Conocimientos profesionales</label>
        <input type="text" class="form-control" id="" placeholder="">
      <label class="input-group-text">Funciones</label>
        <input type="text" class="form-control" id="" placeholder="">
      <label class="input-group-text">Sueldo ofertado</label>
        <input type="text" class="form-control" id="" placeholder="">
  </div>
  <br>
    <button type="submit" class="btn btn-primary">Terminar registro</button>
  </div>
  <form>
</div>
    
</body>
</html>