<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="{{asset('js/jquery.js')}}"></script>
    <script src="{{asset('js/bootstrap.js')}}"></script>
    <script src="{{asset('js/bootstrap.bundle.js')}}"></script>
    <title>Nosotros</title>
</head>
<body>
<!--div menu -->
        <ul class="nav justify-content-center navbar navbar-dark bg-primary">
            <li class="navbar-brand">
                <a class="btn btn-light" href="/">Inicio</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="/Nosotros">Nosotros</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="/Informacion">Más información</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="/Registrar-Empresa">Registrar empresa</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-warning" href="/Postularme">Postularme</a>
            </li>
        </ul>
    <br>
    <br>
    <div class="container">
    <br><br>
                    <!--div PROCESO DE RECLUTAMIENTO -->
        <div class="row">
            <h1 class="text-primary">¿Cómo puedo ser candidato a un puesto ?</h1>
            <br><br><br>
            <div class="col-md-3 ; card w-40" style="background-color: #CCEFFF">
                <h3>paso 1</h3>
                <p>Aqui se describe el paso</p>
            </div>

            <div class="col-md-3 ; card w-40" >
                <h3>paso 1</h3>
                <p>Aqui se describe el paso</p>
            </div>

            <div class="col-md-3 ; card w-40" style="background-color: #CCEFFF">
                <h3>paso 1</h3>
                <p>Aqui se describe el paso</p>
            </div>

            <div class="col-md-3 ; card w-40">
                <h3>paso 1</h3>
                <p>Aqui se describe el paso</p>
            </div>

        </div>
        <br><br>
                    <!--div RUBROS DE EMPRESAS AFILIADAS A CANACINTRA -->
        <div>
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="/imgs/jobs.png" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="/imgs/descarga.png" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="/imgs/jobs.png" alt="Third slide">
                    </div>
                </div>
            </div>
        </div>
        <br><br>
                    <!--div DESCRIPCION DE LAS FUENTES DE INFORMACION-->
        <div class="row">
            <div class="col-md-3 ; card w-40">
                    <div class="card-body">
                        <h3 class="card-title ; text-primary">INEGI</h3>
                        <p class="card-text ; text-justify">Somos un organismo público autónomo responsable de normar y coordinar el Sistema Nacional de Información Estadística y Geográfica, así como de captar y difundir información de México en cuanto al territorio, los recursos, la población y economía, que permita dar a conocer las características de nuestro país y ayudar a la toma de decisiones.</p>
                    </div>
            </div>

            <div class="col-md-3 ; card w-40">
            <img src="/imgs/inegi_logo.png" alt="logo_inegi">
            </div>

            <div class="col-md-3 ; card w-40">
                    <div class="card-body">
                        <h3 class="card-title ; text-primary">CANACINTRA</h3>
                        <p class="card-text">La Cámara afilia a empresas micro, pequeñas, medianas, grandes y globales a lo largo del territorio nacional; cabe destacar que cerca del 75% de las afiliadas son MIPYMES, lo cual convierte a CANACINTRA en el organismo empresarial con mayor cobertura e infraestructura en México.</p>
                    </div>
            </div>

            <div class="col-md-3 ; card w-40">
            <img src="/imgs/canacintra_logo.png" alt="logo_canacintra">
            </div>

        </div>
        <br><br>
                        <!--div OBJERTIVOS DE LA OMS-->
        <div class="row">
            <div>
                    <img src="/imgs/ODS_logo.jpg" alt="">
            </div>
            <br><br>

            <div class="col-md-3 ; card w-40">
                    <div class="card-body">
                        <img src="/imgs/ODS1.png" alt="">
                    </div>
            </div>

            <div class="col-md-3 ; card w-40">
                    <div class="card-body">
                        <h3 class="card-title ; text-primary">8. Trabajo decente y crecimiento económico</h3>
                        <p class="card-text">8.3  Promover políticas orientadas al desarrollo que apoyen las actividades productivas, la creación de puestos de trabajo decentes, el emprendimiento, la creatividad y la innovación, y fomentar la formalización y el crecimiento de las microempresas y las pequeñas y medianas empresas, incluso mediante el acceso a servicios financieros</p>
                    </div>
            </div>

            <div class="col-md-3 ; card w-20">
                    <div class="card-body">
                        <img src="/imgs/ODS8.jpg" alt="">
                    </div>
            </div>

            <div class="col-md-3 ; card w-40">
                    <div class="card-body">
                        <h3 class="card-title ; text-primary">1. Fin de la pobreza</h3>
                        <p class="card-text">1.5   Para 2030, fomentar la resiliencia de los pobres y las personas que se encuentran en situaciones vulnerables y reducir su exposición y vulnerabilidad a los fenómenos extremos relacionados con el clima y a otros desastres económicos, sociales y ambientales.</p>
                    </div>
            </div>

        </div>
    </div>
    <script src="/static/js/bootstrap.js"></script>
</body>
</html>