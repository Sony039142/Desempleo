<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/app.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <title>Registrar mi empresa</title>
</head>
<body>
     <!--div menu -->
     <ul class="nav justify-content-center navbar navbar-dark bg-primary">
        <li class="navbar-brand">
            <a class="btn btn-light" href="/">Inicio</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Nosotros">Nosotros</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Info">Más información</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="Reg_empresa.html">Registrar empresa</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-warning" href="/Postularme">Postularme</a>
        </li>
    </ul>
<br>
<br>
<div class="container">
<br><br>
<h3>Nombre completo</h3>
  <form>
    <div class="input-group">
        <!--div nombre completo-->
        <label class="input-group-text">Nombre(s)</label>
        <input type="text" class="form-control" id="apepat" placeholder="Nombres">
        <label class="input-group-text">Primer apellido</label>
        <input type="text" class="form-control" id="apepat" placeholder="Primer apellido">
  
       <label class="input-group-text">Segundo apellido</label>
       <input type="text" class="form-control" id="apemat" placeholder="Segundo apellido">
      </div>
    <br>
    <h5>Contactos</h5>
     <!--div Contacto de la empresa-->
    <div class="input-group">
        <label class="input-group-text">Telefono</label>
        <input type="" class="form-control" id="Tel" placeholder="Lada + numero">
        <label class="input-group-text">Correo ELectronico</label>
        <input type="email" class="form-control" id="mail" placeholder="mail@gmail.com">
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Terminar registro</button>
    
  <form>
</div>
    
</body>
</html>