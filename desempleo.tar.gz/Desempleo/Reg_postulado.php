<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/app.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <title>Postularme</title>
</head>
<body>
     <!--MENU PRINCIPAL -->
     <ul class="nav justify-content-center navbar navbar-dark bg-primary">
        <li class="navbar-brand">
            <a class="btn btn-light" href="/">Inicio</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Nosotros">Nosotros</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="/Info">Más información</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-light" href="Reg_empresa.php">Registrar empresa</a>
        </li>
        <li class="navbar-brand">
            <a class="btn btn-warning" href="/Postularme">Postularme</a>
        </li>
    </ul>
<br>
<div class="container">
<br><br>
<h3>Requisitos para postularse</h3>
<br>
                        <!--FORMULARIO DE POSTULADOS-->
  <form name="formpostulados" method="POST" action="RegistroPostulado.php">
    <div class="container">
    <h5>Datos generales</h5>
    <div class="input-group">
      <!--div nombre completo-->
      <label class="input-group-text">Nombre(s)</label>
        <input type="text" class="form-control" name="Nombre" placeholder="Nombres">
      <label class="input-group-text">Primer apellido</label>
        <input type="text" class="form-control" name="App" placeholder="Primer apellido">
      <label class="input-group-text">Segundo apellido</label>
        <input type="text" class="form-control" name="Apm" placeholder="Segundo apellido">
    </div>
      <br>
      </html>
    <div class="input-group">
      <!--div datos generales -->
      <label class="input-group-text">Estado Civil</label>
        <select class="form-control" id="EstCivil"></select>

      <label class="input-group-text">Sexo</label>
        <select class="form-control" id="Sexo">
          <option>los tomara de la base de datos </option>
        </select>
    </div>
    <br>
    <div class="input-group">
      <label class="input-group-text">Fecha de nacimiento</label>
        <input type="text" class="form-control" name="FechaNac" placeholder="Fecha de nacimiento">
      <label class="input-group-text">Edad</label>
        <input type="text" class="form-control" name="Edad" placeholder="Edad">
    </div>

    <!--div Direccion del postulado-->
      <br>
      <h5>Dirección del postulado</h5>
      <br>
    <div class="input-group">
    <!--div estado -->
         <label class="input-group-text">Estado</label>
            <select class="form-control" name="Estado">
                <option>los tomara de la base de datos </option>
            </select>
  
            <label class="input-group-text">Municipio</label>
          <select class="form-control" name="Municipio">
            <option>los tomara de la base de datos </option>
          </select>

        <label class="input-group-text">Calle principal</label>
        <input type="text" class="form-control" name="Calle" placeholder="Avenida 1">
        <!--<label class="input-group-text">Calle secundaria</label>
        <input type="text" class="form-control">
        <input type="text" class="form-control">-->
    </div>
    <br>
    <h5>Contactos</h5>
     <!--div Contacto del postulado-->
    <div class="input-group">
        <label class="input-group-text">Telefono</label>
        <input type="" class="form-control" name="Telefono" placeholder="Lada + numero">
        <label class="input-group-text">Correo ELectronico</label>
        <input type="email" class="form-control" name="Correo" placeholder="admin@empresa.com">
    </div>
    <br>
    <!--div Datos profesionales-->
    <br>
    <h5>Datos profesionales</h5>
    <br>
  <div class="input-group">
      <label class="input-group-text">Nivel de estudios</label>
          <select class="form-control" name="NivelAca">
              <option>los tomara de la base de datos </option>
          </select>

      <label class="input-group-text">Area profesional</label>
        <select class="form-control" name="Area">
          <option>los tomara de la base de datos </option>
        </select>
  </div>
  <br>
  <div class="input-group">
      <label class="input-group-text">Conocimientos profesionales</label>
        <input type="text" class="form-control" name="ConAca" placeholder="">
      <label class="input-group-text">Presentación profesional</label>
        <input type="text" class="form-control" name="PresPro" placeholder="">
      <label class="input-group-text">Sueldo deseado</label>
        <input type="text" class="form-control" name="SueldoD" placeholder="">
  </div>
  <br>
    <button type="submit" class="btn btn-primary">Terminar registro</button>
  </div>
  <form>
</div>
    
</body>
</html>