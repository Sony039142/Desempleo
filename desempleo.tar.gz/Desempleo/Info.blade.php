<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="{{asset('js/jquery.js')}}"></script>
    <script src="{{asset('js/bootstrap.js')}}"></script>
    <script src="{{asset('js/bootstrap.bundle.js')}}"></script>
    <title>Informacion</title>
</head>
<body>
<!--div menu -->
        <ul class="nav justify-content-center navbar navbar-dark bg-primary">
            <li class="navbar-brand">
                <a class="btn btn-light" href="/">Inicio</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="/Nosotros">Nosotros</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="/Info">Más información</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-light" href="">Registrar empresa</a>
            </li>
            <li class="navbar-brand">
                <a class="btn btn-warning" href="/Postularme">Postularme</a>
            </li>
        </ul>
    <br>
    <br>
    <div class="container">
    <br><br>


    </div>
    <script src="/static/js/bootstrap.js"></script>
</body>
</html>